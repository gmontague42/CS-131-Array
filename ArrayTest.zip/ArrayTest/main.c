/****************************************************************************
* Project: ArrayTest
* File: main.c
* Author: Gwendolyn Montague
* Date: 10/07/2020
* Description: This console-based program practices how to read in arrays
*              add pass their values to different functions.
****************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#define SIZE 10

int calcTotal(int arr[][3], int rows);
int main()
{
    //declare variables
//    int nums[SIZE];
//    int exp;
    //fill array
//    for (int i = 0; i < SIZE; i++)
//        nums[i] = pow(2, i);
    //get exponent
//    printf("%s", "Enter an exponent between 0 and 9: ");
//    scanf("%d", &exp);
    //output power of 2
//    printf("2^%d = %d\n", exp, nums[exp]);

//int grades[100];
//int count = 0;
//int input;
//double avg;
//do
//{
// printf("%s", "Enter a grade (-1 to quit): ");
// scanf("%d", &input);
// if (input >= 0)
// grades[count++] = input;

//}while (input >= 0 && count < 100)
//for (int i = 0; i < count; i++)
//    avg += grades[i];
//avg /= (double)count;
//printf("Average = %f", avg);//
    int hours [7][3];
    int total = 0;
    for (int i = 0; i < 7; i++)
        for(int j = 0; j < 3; j++)
        {
            printf("Hours worked for day %i shift %j: ", i, j);
            scanf("%d", &hours[i][j]);
        }
    total = calcTotal(hours, 7);
    printf("Total hours worked this week = %d\n", total);
}
int calcTotal(int arr[][3], int rows)
{
    int total = 0;
    for (int i = 0; i < rows; i++)
        for (int j = 0; j < 3; j++)
            total += arr[i][j];
    return total;
}
